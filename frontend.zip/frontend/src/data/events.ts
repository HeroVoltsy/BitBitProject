import type { Category, EventItem } from "../types";

/** An event the current user organized, with the ratings it received (reviews 0 = unrated). */
export type OrganizedEvent = EventItem & { dateLabel: string; rating: number; reviews: number };

export const CATEGORIES: Category[] = [
  "Market",
  "Music",
  "Sports",
  "Volunteer",
  "Fun Run",
  "Concert",
  "Pop-Up",
];

/** Feed shown on the Home screen ("Events Around You"). */
export const FEED_EVENTS: EventItem[] = [
  {
    id: "naga-sunday-market",
    title: "Naga Sunday Market",
    category: "Market",
    monthLabel: "AUG",
    day: "23",
    dateLine: "Sun, Aug 23 · 10:00 AM",
    location: "Plaza Rizal, Naga City",
    going: 12,
    hosting: true,
  },
  {
    id: "acoustic-avenue",
    audiences: ["student","professional"],
    title: "Acoustic Nights at the Avenue",
    category: "Music",
    monthLabel: "AUG",
    day: "25",
    dateLine: "Tue, Aug 25 · 6:30 PM",
    location: "Avenue Square, Magsaysay Ave",
    going: 45,
    attending: true,
  },
  {
    id: "naga-river-cleanup",
    audiences: ["student","teacher"],
    title: "Naga River Clean-up Drive",
    category: "Volunteer",
    monthLabel: "AUG",
    day: "29",
    dateLine: "Sat, Aug 29 · 8:00 AM",
    location: "Naga River Esplanade",
    going: 8,
    attending: true,
  },
  {
    id: "frisbee-friendly",
    audiences: ["student","professional"],
    title: "Weekend Frisbee Friendly",
    category: "Sports",
    monthLabel: "SEP",
    day: "02",
    dateLine: "Wed, Sep 02 · 5:00 PM",
    location: "Metro Naga Sports Complex",
    going: 19,
  },
  {
    id: "naga-fun-run",
    audiences: ["teacher","professional","self_employed"],
    title: "Naga City Fun Run 2026",
    category: "Fun Run",
    monthLabel: "SEP",
    day: "27",
    dateLine: "Sun, Sep 27 · 5:00 AM",
    location: "Plaza Rizal, Naga City",
    going: 230,
  },
  {
    id: "penafrancia-concert",
    audiences: ["student","professional"],
    title: "Peñafrancia Grand Concert",
    category: "Concert",
    monthLabel: "SEP",
    day: "19",
    dateLine: "Sat, Sep 19 · 7:00 PM",
    location: "Plaza Quezon, Naga City",
    going: 540,
  },
  {
    id: "centro-popup",
    audiences: ["business_owner","self_employed"],
    title: "Centro Pop-Up Bazaar",
    category: "Pop-Up",
    monthLabel: "SEP",
    day: "12",
    dateLine: "Sat, Sep 12 · 3:00 PM",
    location: "Magsaysay Ave, Naga City",
    going: 96,
  },
];

/** Schedule entries used on the Calendar screen. */
export const SCHEDULE = [
  {
    date: "August 23",
    items: [
      {
        title: "Naga Sunday Market",
        time: "10:00 AM - 2:00 PM",
        location: "Plaza Rizal, Naga City",
      },
      {
        title: "Sunset Yoga at the Plaza",
        time: "5:30 PM - 6:30 PM",
        location: "Plaza Quezon, Naga City",
      },
    ],
  },
];

export type EventStatus = "Ongoing" | "Upcoming" | "Finished";

export interface CalendarEvent {
  title: string;
  time: string;
  location: string;
  category: Category;
  status: EventStatus;
}

/**
 * Events keyed by date ("YEAR-MONTHINDEX-DAY", month is 0-indexed).
 * Clicking a day in the calendar shows that day's events.
 */
export const CALENDAR_EVENTS: Record<string, CalendarEvent[]> = {
  "2026-7-23": [
    {
      title: "Naga Sunday Market",
      time: "10:00 AM - 2:00 PM",
      location: "Plaza Rizal, Naga City",
      category: "Market",
      status: "Ongoing",
    },
    {
      title: "Sunset Yoga at the Plaza",
      time: "5:30 PM - 6:30 PM",
      location: "Plaza Quezon, Naga City",
      category: "Sports",
      status: "Upcoming",
    },
  ],
  "2026-7-25": [
    {
      title: "Acoustic Nights at the Avenue",
      time: "6:30 PM - 9:00 PM",
      location: "Avenue Square, Magsaysay Ave",
      category: "Music",
      status: "Upcoming",
    },
  ],
  "2026-7-29": [
    {
      title: "Naga River Clean-up Drive",
      time: "8:00 AM - 11:00 AM",
      location: "Naga River Esplanade",
      category: "Volunteer",
      status: "Finished",
    },
  ],
  "2026-8-2": [
    {
      title: "Weekend Frisbee Friendly",
      time: "5:00 PM - 7:00 PM",
      location: "Metro Naga Sports Complex",
      category: "Sports",
      status: "Upcoming",
    },
  ],
};

/** Events the current user is attending (Profile screen). */
export const GOING_LIST = [
  {
    title: "Acoustic Nights at the Avenue",
    meta: "Aug 25 · 6:30 PM",
    location: "Avenue Square, Magsaysay Ave",
  },
  {
    title: "Naga River Clean-up Drive",
    meta: "Aug 29 · 8:00 AM",
    location: "Naga River Esplanade",
  },
];

/** Map bottom-sheet mini cards. */
export const MAP_CARDS = [
  { title: "Naga Sunday Market", location: "Plaza Rizal, Naga City", category: "Market" as Category },
  { title: "Acoustic Nights", location: "Magsaysay Ave", category: "Music" as Category },
  { title: "Frisbee Friendly", location: "Metro Naga Sports Complex", category: "Sports" as Category },
];

/** Recent scans on the QR check-in screen. */
export const RECENT_CHECKINS = [
  { id: "CMN-29402", ago: "2 min ago" },
  { id: "CMN-08341", ago: "10 min ago" },
  { id: "CMN-77321", ago: "24 min ago" },
];

/** Attendance roster. */
export const ATTENDEES = [
  { name: "Maria Santos", id: "CMN-29402", status: "IN" as const },
  { name: "Jose dela Cruz", id: "CMN-08341", status: "IN" as const },
  { name: "Andrea Reyes", id: "CMN-77321", status: "IN" as const },
  { name: "Paolo Mendoza", id: "CMN-49018", status: "IN" as const },
  { name: "Kristine Bautista", id: "CMN-88102", status: "IN" as const },
  { name: "Miguel Torres", id: "CMN-31045", status: "PENDING" as const },
  { name: "Angela Villanueva", id: "CMN-99120", status: "PENDING" as const },
  { name: "Carlo Aquino", id: "CMN-10492", status: "PENDING" as const },
];

export const USER = {
  name: "Kyle Sta. Rosa",
  firstName: "Kyle",
  email: "kyle.starosa@community.com",
  memberSince: "Member since Mar 2024",
  initials: "KR",
};

/** Every event the current user has organized, newest first. Profile stats are derived from this. */
export const ORGANIZED_EVENTS: OrganizedEvent[] = [
  { ...FEED_EVENTS[0], dateLabel: "Aug 23, 2026", rating: 4.9, reviews: 21 },
  {
    id: "kinalas-food-crawl",
    title: "Kinalas Food Crawl",
    category: "Pop-Up",
    monthLabel: "JUN",
    day: "28",
    dateLine: "Sun, Jun 28 · 4:00 PM",
    location: "Centro, Naga City",
    going: 64,
    hosting: true,
    dateLabel: "Jun 28, 2026",
    rating: 4.8,
    reviews: 34,
  },
  {
    id: "barangay-fun-run",
    title: "Barangay Fun Run",
    category: "Fun Run",
    monthLabel: "MAY",
    day: "10",
    dateLine: "Sun, May 10 · 5:30 AM",
    location: "Brgy. Concepcion Pequeña, Naga City",
    going: 88,
    hosting: true,
    dateLabel: "May 10, 2026",
    rating: 4.7,
    reviews: 15,
  },
  {
    id: "plaza-night-market",
    title: "Plaza Rizal Night Market",
    category: "Market",
    monthLabel: "MAR",
    day: "21",
    dateLine: "Sat, Mar 21 · 6:00 PM",
    location: "Plaza Rizal, Naga City",
    going: 120,
    hosting: true,
    dateLabel: "Mar 21, 2026",
    rating: 4.6,
    reviews: 12,
  },
  {
    id: "riverside-cleanup",
    title: "Riverside Clean-up Day",
    category: "Volunteer",
    monthLabel: "JAN",
    day: "17",
    dateLine: "Sat, Jan 17 · 7:00 AM",
    location: "Naga River Esplanade",
    going: 27,
    hosting: true,
    dateLabel: "Jan 17, 2026",
    rating: 5.0,
    reviews: 6,
  },
];

/** People who follow the current user. */
export const FOLLOWERS = [
  { name: "Maria Santos", location: "Brgy. Concepcion Pequeña", followingBack: true },
  { name: "Jose dela Cruz", location: "Brgy. Triangulo", followingBack: true },
  { name: "Andrea Reyes", location: "Brgy. Sabang", followingBack: false },
  { name: "Paolo Mendoza", location: "Brgy. Calauag", followingBack: true },
  { name: "Kristine Bautista", location: "Brgy. Peñafrancia", followingBack: false },
  { name: "Miguel Torres", location: "Brgy. Abella", followingBack: false },
  { name: "Angela Villanueva", location: "Brgy. Dinaga", followingBack: true },
  { name: "Carlo Aquino", location: "Brgy. Tabuco", followingBack: false },
  { name: "Bea Fernandez", location: "Brgy. Lerma", followingBack: false },
  { name: "Rafael Lim", location: "Brgy. Pacol", followingBack: true },
  { name: "Joanna Cruz", location: "Brgy. Bagumbayan Norte", followingBack: false },
  { name: "Enzo Ramirez", location: "Brgy. San Felipe", followingBack: false },
];

const RATED = ORGANIZED_EVENTS.filter((e) => e.reviews > 0);
const TOTAL_REVIEWS = RATED.reduce((sum, e) => sum + e.reviews, 0);

/** Public reputation stats for the current user (and host profile), derived from the lists above. */
export const HOST_STATS = {
  hosted: ORGANIZED_EVENTS.length,
  followers: FOLLOWERS.length,
  reviews: TOTAL_REVIEWS,
  // Average of all individual reviews (weighted by each event's review count).
  rating: TOTAL_REVIEWS
    ? RATED.reduce((sum, e) => sum + e.rating * e.reviews, 0) / TOTAL_REVIEWS
    : 0,
};

/**
 * Past events the current user joined (sample data). In the real app the
 * backend returns these, split from upcoming events by each event's real date.
 */
export type PastEvent = EventItem & { dateLabel: string; hostName: string };
export const PAST_JOINED_EVENTS: PastEvent[] = [
  {
    id: "naga-food-festival",
    title: "Naga Food Festival",
    category: "Pop-Up",
    monthLabel: "OCT",
    day: "18",
    dateLine: "Sun, Oct 18 · 4:00 PM",
    location: "Plaza Quezon, Naga City",
    going: 310,
    attending: true,
    ended: true,
    dateLabel: "Oct 18, 2026",
    hostName: "Andrea Reyes",
  },
  {
    id: "bicol-indie-night",
    title: "Bicol Indie Music Night",
    category: "Concert",
    monthLabel: "OCT",
    day: "03",
    dateLine: "Sat, Oct 03 · 7:00 PM",
    location: "Avenue Square, Magsaysay Ave",
    going: 150,
    attending: true,
    ended: true,
    dateLabel: "Oct 3, 2026",
    hostName: "Paolo Mendoza",
  },
  {
    id: "coastal-cleanup",
    title: "Coastal Clean-up Saturday",
    category: "Volunteer",
    monthLabel: "SEP",
    day: "05",
    dateLine: "Sat, Sep 05 · 6:00 AM",
    location: "Pasacao Beach, Camarines Sur",
    going: 42,
    attending: true,
    ended: true,
    dateLabel: "Sep 5, 2026",
    hostName: "Miguel Torres",
  },
  {
    id: "sunrise-5k",
    title: "Sunrise 5K Run",
    category: "Fun Run",
    monthLabel: "JUL",
    day: "12",
    dateLine: "Sun, Jul 12 · 5:00 AM",
    location: "Metro Naga Sports Complex",
    going: 180,
    attending: true,
    ended: true,
    dateLabel: "Jul 12, 2026",
    hostName: "Kristine Bautista",
  },
];

/** Look up any known event (feed, organized, or past) by id. */
export function findEvent(id: string): EventItem | undefined {
  return (
    FEED_EVENTS.find((e) => e.id === id) ??
    ORGANIZED_EVENTS.find((e) => e.id === id) ??
    PAST_JOINED_EVENTS.find((e) => e.id === id)
  );
}
